import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getProperties } from '../services/api';

const Home = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true);
        const data = await getProperties();
        setProperties(data || []);
        setError(null);
      } catch (err) {
        console.error('API Error:', err);
        
        // Fallback بيانات وهمية لو الـ API فشل
        setProperties([
          {
            id: 1,
            title: "شقة مفروشة 3 غرف في المهندسين",
            price: 15000,
            location: "المهندسين - شارع شهاب",
            area: 120,
            bedrooms: 3,
            bathrooms: 2,
            images: ["https://images.housesolutionegypt.com/images/properties/6270/mivida-apartment-for-rent-160m2-3br-3ba-furnished-12.webp"]
          },
          {
            id: 2,
            title: "شقة سوبر لوكس في التجمع الخامس",
            price: 28000,
            location: "التجمع الخامس",
            area: 150,
            bedrooms: 3,
            bathrooms: 3,
            images: ["https://a0.muscache.com/im/pictures/hosting/Hosting-1389704208895953397/original/462d40ba-bfe0-48e1-b477-240afe2726f3.jpeg"]
          }
        ]);
        setError('جاري استخدام بيانات تجريبية (الـ API مش متاح حالياً)');
      } finally {
        setLoading(false);
      }
    };

    fetchProperties();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    
    // حل المشكلة دي: نروح على الـ login + نعمل reload عشان App يتحدث
    window.location.href = '/login';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-base-200">
        <span className="loading loading-spinner loading-lg text-primary"></span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-base-200 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-5xl font-bold">🏠 العقارات المتاحة</h1>
          <button onClick={handleLogout} className="btn btn-outline">
            تسجيل خروج
          </button>
        </div>

        {error && <div className="alert alert-warning mb-6">{error}</div>}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.map((prop) => (
            <Link
              key={prop.id}
              to={`/property/${prop.id}`}
              className="card bg-base-100 shadow-xl hover:shadow-2xl transition-all"
            >
              <figure className="h-56">
                <img 
                  src={prop.images?.[0] || 'https://via.placeholder.com/600x400?text=شقة'} 
                  alt={prop.title}
                  className="w-full h-full object-cover"
                />
              </figure>
              <div className="card-body">
                <h2 className="card-title">{prop.title}</h2>
                <p className="text-3xl font-bold text-purple-600">
                  {prop.price} ج.م <span className="text-base">شهرياً</span>
                </p>
                <p className="text-sm text-gray-500">📍 {prop.location}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;