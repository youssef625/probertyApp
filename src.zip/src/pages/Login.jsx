import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../services/api';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);

      // إجبار الـ App على تحديث الحالة
      window.dispatchEvent(new Event('storage'));

      navigate('/', { replace: true });
    } catch (err) {
      setError('الإيميل أو كلمة السر غلط. جرب تاني.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center p-4">
      <div className="card bg-base-100 shadow-2xl w-full max-w-md">
        <div className="card-body">
          <h1 className="text-3xl font-bold text-center mb-6 text-purple-600">RentVibe</h1>

          {error && <div className="alert alert-error mb-4">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label">الإيميل</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input input-bordered w-full"
                placeholder="admin@rentvibe.com"
                required
              />
            </div>

            <div>
              <label className="label">كلمة السر</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input input-bordered w-full"
                placeholder="Admin@123"
                required
              />
            </div>

            <button 
              type="submit" 
              className="btn btn-primary w-full h-12 text-lg"
              disabled={loading}
            >
              {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
            </button>
          </form>

          <div className="text-center mt-6">
            <Link to="/register" className="text-purple-600 hover:underline">
              ليس لديك حساب؟ إنشاء حساب جديد
            </Link>
          </div>

          <div className="text-center text-xs text-gray-500 mt-4">
            للتجربة: admin@rentvibe.com / Admin@123
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;