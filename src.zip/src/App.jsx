import { Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

import Login from './pages/Login';
import Register from './pages/Register';   // هتضيفها بعد شوية
import Home from './pages/Home';
import PropertyView from './pages/PropertyView';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const checkAuth = () => {
      const token = localStorage.getItem('token');
      setIsAuthenticated(!!token);
    };

    checkAuth();

    // استمع لأي تغيير في localStorage
    window.addEventListener('storage', checkAuth);

    return () => window.removeEventListener('storage', checkAuth);
  }, []);

  return (
    <Routes>
      <Route path="/login" element={isAuthenticated ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/register" element={isAuthenticated ? <Navigate to="/" replace /> : <Register />} />
      <Route path="/" element={isAuthenticated ? <Home /> : <Navigate to="/login" replace />} />
      <Route path="/property/:id" element={isAuthenticated ? <PropertyView /> : <Navigate to="/login" replace />} />
      <Route path="*" element={<div className="min-h-screen flex items-center justify-center text-2xl">404 - الصفحة غير موجودة</div>} />
    </Routes>
  );
}

export default App;