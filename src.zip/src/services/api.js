// src/services/api.js

// Base URL for the RentVibe API
const API_BASE_URL = 'https://app-260407103838.azurewebsites.net/api';

// Helper function to get auth headers with Bearer token
const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` })
  };
};

// =====================================================
// 🔹 Authentication
// =====================================================

export const login = async (email, password) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      throw new Error('Invalid email or password');
    }

    const data = await response.json();

    if (data.token) {
      localStorage.setItem('token', data.token);

      // حفظ الـ role من الـ Backend (لو رجعه)
      if (data.role) {
        localStorage.setItem('role', data.role.toLowerCase());
      } 
      // لو الـ backend مش بيرجع role، نحكم من الإيميل
      else if (email.toLowerCase().includes('landlord') || email.toLowerCase().includes('owner')) {
        localStorage.setItem('role', 'landlord');
      } else {
        localStorage.setItem('role', 'tenant');
      }
    }

    return data;
  } catch (error) {
    console.error('Login failed:', error);
    throw error;
  }
};

export const logout = () => {
  localStorage.removeItem('token');
};

export const getCurrentUser = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/Auth/me`, {
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to fetch user');
    return await response.json();
  } catch (error) {
    console.error('❌ getCurrentUser error:', error);
    throw error;
  }
};

// =====================================================
// 🔹 Properties
// =====================================================

export const getProperties = async (filters = {}) => {
  try {
    const params = new URLSearchParams(filters).toString();
    const url = `${API_BASE_URL}/Properties${params ? `?${params}` : ''}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      if (response.status === 401) throw new Error('Unauthorized');
      throw new Error(`Failed to fetch properties: ${response.status}`);
    }
    
    return await response.json();
    
  } catch (error) {
    console.error('❌ getProperties error:', error);
    throw error;
  }
};

export const getPropertyById = async (id) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Properties/${id}`, {
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) throw new Error('Failed to fetch property');
    return await response.json();
    
  } catch (error) {
    console.error('❌ getPropertyById error:', error);
    throw error;
  }
};

export const createProperty = async (propertyData) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Properties`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(propertyData),
    });
    
    if (!response.ok) throw new Error('Failed to create property');
    return await response.json();
    
  } catch (error) {
    console.error('❌ createProperty error:', error);
    throw error;
  }
};

// =====================================================
// 🔹 Favorites
// =====================================================

export const getFavorites = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/Favorites`, {
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to fetch favorites');
    return await response.json();
  } catch (error) {
    console.error('❌ getFavorites error:', error);
    throw error;
  }
};

export const addToFavorites = async (propertyId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Favorites/${propertyId}`, {
      method: 'POST',
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) {
      if (response.status === 401) throw new Error('Unauthorized');
      throw new Error('Failed to add to favorites');
    }
    
    return await response.json();
    
  } catch (error) {
    console.error('❌ addToFavorites error:', error);
    throw error;
  }
};

export const removeFromFavorites = async (propertyId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Favorites/${propertyId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    
    if (!response.ok) throw new Error('Failed to remove from favorites');
    return await response.json();
    
  } catch (error) {
    console.error('❌ removeFromFavorites error:', error);
    throw error;
  }
};

// =====================================================
// 🔹 Visits
// =====================================================

export const scheduleVisit = async (propertyId, requestedDate, message = '') => {
  try {
    const response = await fetch(`${API_BASE_URL}/Visits`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        propertyId: parseInt(propertyId),
        requestedDate: requestedDate,
        message: message,
      }),
    });
    
    if (!response.ok) throw new Error('Failed to schedule visit');
    return await response.json();
    
  } catch (error) {
    console.error('❌ scheduleVisit error:', error);
    throw error;
  }
};

export const getMyVisits = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/Visits/my`, {
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to fetch visits');
    return await response.json();
  } catch (error) {
    console.error('❌ getMyVisits error:', error);
    throw error;
  }
};

// =====================================================
// 🔹 Reviews
// =====================================================

export const getPropertyReviews = async (propertyId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Reviews/property/${propertyId}`, {
      headers: getAuthHeaders(),
    });
    if (!response.ok) throw new Error('Failed to fetch reviews');
    return await response.json();
  } catch (error) {
    console.error('❌ getPropertyReviews error:', error);
    throw error;
  }
};

export const createReview = async (propertyId, rating, comment = '') => {
  try {
    const response = await fetch(`${API_BASE_URL}/Reviews`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ propertyId, rating, comment }),
    });
    if (!response.ok) throw new Error('Failed to create review');
    return await response.json();
  } catch (error) {
    console.error('❌ createReview error:', error);
    throw error;
  }
};

export const register = async (userData) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to register');
    }

    return await response.json();
  } catch (error) {
    console.error('Register error:', error);
    throw error;
  }
};