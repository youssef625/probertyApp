export const properties = [
  {
    id: '1',
    title: "شقة مفروشة فاخرة 3 غرف في قلب المهندسين",
    price: 15000,
    area: 120,
    bedrooms: 3,
    bathrooms: 2,
    location: "المهندسين - شارع شهاب",
    status: "متاحة الآن",
    thumbnail: "https://images.housesolutionegypt.com/images/properties/6270/mivida-apartment-for-rent-160m2-3br-3ba-furnished-12.webp",
    // الشرح الكابشن اللي انا عاوزه
  },
  {
    id: '2',
    title: "شقة 3 غرف مفروشة سوبر لوكس - نيو كايرو",
    price: 28000,
    area: 150,
    bedrooms: 3,
    bathrooms: 3,
    location: "التجمع الخامس - كمبوند",
    status: "متاحة",
    thumbnail: "https://a0.muscache.com/im/pictures/hosting/Hosting-1389704208895953397/original/462d40ba-bfe0-48e1-b477-240afe2726f3.jpeg",
  },
  {
    id: '3',
    title: "شقة مفروشة 3 غرف مطلة على النيل - الزمالك",
    price: 35000,
    area: 140,
    bedrooms: 3,
    bathrooms: 2,
    location: "الزمالك - فيو نيل",
    status: "متاحة قريبًا",
    thumbnail: "https://a0.muscache.com/im/pictures/hosting/Hosting-1197153629879952777/original/7abc2df0-8c76-4d3f-8452-7d8b18397c36.jpeg",
  },
  // ممكن اضيف عدد من الكميه اللي انا عاوزها يبالطريقة دي 
  // عاوز اعمل حركة الا و هي ان عاوز اعمل نظام الكارد بس اضسفة من الباك او عن طريق الادمن
  
];
